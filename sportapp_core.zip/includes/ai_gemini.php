<?php
/**
 * Revisi 16 Juni 2026 — Helper Google Gemini 2.5 Flash
 *
 * Dipakai oleh:
 *  - api_run.php           (AI Route dari gambar peta & dari prompt teks)
 *  - kalori_mingguan.php   (estimasi kalori dari foto makanan)
 *  - monitoring.php        (AI Running Coach)
 *  - islami.php            (Tanya Jawab Islami)
 *  - live_tracking.php     (AI Safety Monitoring)
 *
 * Key default sesuai permintaan user (boleh override lewat env GEMINI_API_KEY).
 */

if (!defined('GEMINI_API_KEY')) {
    define('GEMINI_API_KEY', getenv('GEMINI_API_KEY') ?: 'AQ.Ab8RN6Ih3agk9Ci-i4ChaLerRnJOK-OpOFF4qgL8y99ZZEC5kQ');
}
if (!defined('GEMINI_MODEL')) {
    define('GEMINI_MODEL', getenv('GEMINI_MODEL') ?: 'gemini-2.5-flash');
}
if (!defined('MAPBOX_TOKEN')) {
    define('MAPBOX_TOKEN', getenv('MAPBOX_TOKEN') ?: 'pk.eyJ1IjoiYWRhbXNhc21pdGE1MzQiLCJhIjoiY21xZnRsbWxjMXZldDJ0cHlhN2Jycnd1dCJ9.2E00ey-sgX9jUmf5kIRoEA');
}

/**
 * Panggil Gemini generateContent.
 * @param array $parts  array of [ ['text'=>'...'] , ['inline_data'=>['mime_type'=>...,'data'=>base64]] , ... ]
 * @param array $opts   optional: ['system'=>string, 'temperature'=>float, 'json'=>bool, 'max_tokens'=>int]
 * @return array        ['ok'=>bool, 'text'=>string|null, 'err'=>string|null, 'raw'=>array]
 */
function gemini_call(array $parts, array $opts = []): array {
    $key = GEMINI_API_KEY;
    if (!$key) return ['ok'=>false,'err'=>'GEMINI_API_KEY belum di-set','text'=>null,'raw'=>[]];

    $body = [
        'contents' => [[ 'role'=>'user', 'parts'=>$parts ]],
        'generationConfig' => [
            'temperature'      => $opts['temperature'] ?? 0.4,
            'maxOutputTokens'  => $opts['max_tokens']  ?? 1024,
        ],
    ];
    if (!empty($opts['json'])) {
        $body['generationConfig']['responseMimeType'] = 'application/json';
    }
    if (!empty($opts['system'])) {
        $body['systemInstruction'] = ['role'=>'system','parts'=>[['text'=>$opts['system']]]];
    }

    $url = 'https://generativelanguage.googleapis.com/v1beta/models/'.GEMINI_MODEL.':generateContent?key='.urlencode($key);
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($body, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($res === false) return ['ok'=>false,'err'=>'curl: '.$err,'text'=>null,'raw'=>[]];
    $j = json_decode($res, true);
    if ($code !== 200) {
        $msg = $j['error']['message'] ?? ('HTTP '.$code);
        return ['ok'=>false,'err'=>$msg,'text'=>null,'raw'=>$j ?: []];
    }
    $text = '';
    foreach (($j['candidates'][0]['content']['parts'] ?? []) as $p) {
        if (isset($p['text'])) $text .= $p['text'];
    }
    return ['ok'=>true,'err'=>null,'text'=>trim($text),'raw'=>$j];
}

/** Versi convenience untuk teks-saja. */
function gemini_text(string $prompt, array $opts = []): array {
    return gemini_call([['text'=>$prompt]], $opts);
}

/** Versi convenience untuk teks + 1 gambar lokal. */
function gemini_vision(string $prompt, string $imagePath, array $opts = []): array {
    if (!is_file($imagePath)) return ['ok'=>false,'err'=>'file gambar tidak ada','text'=>null,'raw'=>[]];
    $mime = mime_content_type($imagePath) ?: 'image/jpeg';
    $b64  = base64_encode(file_get_contents($imagePath));
    return gemini_call([
        ['text'=>$prompt],
        ['inline_data'=>['mime_type'=>$mime,'data'=>$b64]],
    ], $opts);
}

/** Ekstrak JSON object pertama dari respons text bebas. */
function gemini_extract_json(?string $text): ?array {
    if (!$text) return null;
    if (preg_match('/\{[\s\S]*\}/', $text, $m)) {
        $obj = json_decode($m[0], true);
        if (is_array($obj)) return $obj;
    }
    return null;
}