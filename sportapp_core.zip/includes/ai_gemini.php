<?php
/**
 * Revisi 16 Juni 2026 — Helper Google Gemini 2.5 Flash
 *
 * Dipakai oleh:
 *  - api_run.php           (AI Route dari gambar peta & dari prompt teks)
 *  - kalori_mingguan.php   (estimasi kalori dari foto makanan)
 *  - monitoring.php        (AI Running Coach)
 *  - islami.php            (Tanya Jawab Islami)
 *  - live_tracking.php     (AI Safety Monitoring)
 *
 * Key default sesuai permintaan user (boleh override lewat env GEMINI_API_KEY).
 */

if (!defined('GEMINI_API_KEY')) {
    // Revisi 16 Juni 2026 — Key default lama ("AQ.Ab8...") adalah OAuth access token,
    // BUKAN Google API key, sehingga ditolak Gemini ("Request had invalid authentication credentials").
    // Set environment variable GEMINI_API_KEY dengan API key valid yang diawali "AIza..."
    // (dapat dibuat gratis di https://aistudio.google.com/apikey).
    define('GEMINI_API_KEY', getenv('GEMINI_API_KEY') ?: 'AQ.Ab8RN6LDTA_A1I3wsXOwiKGWwGpTgxCH0eaL6mP7dktz-vE_dQ');
}
if (!defined('GEMINI_MODEL')) {
    define('GEMINI_MODEL', getenv('GEMINI_MODEL') ?: 'gemini-2.5-flash');
}
if (!defined('MAPBOX_TOKEN')) {
    define('MAPBOX_TOKEN', getenv('MAPBOX_TOKEN') ?: 'pk.eyJ1IjoiYWRhbXNhc21pdGE1MzQiLCJhIjoiY21xZnRsbWxjMXZldDJ0cHlhN2Jycnd1dCJ9.2E00ey-sgX9jUmf5kIRoEA');
}

/**
 * Panggil Gemini generateContent.
 * @param array $parts  array of [ ['text'=>'...'] , ['inline_data'=>['mime_type'=>...,'data'=>base64]] , ... ]
 * @param array $opts   optional: ['system'=>string, 'temperature'=>float, 'json'=>bool, 'max_tokens'=>int]
 * @return array        ['ok'=>bool, 'text'=>string|null, 'err'=>string|null, 'raw'=>array]
 */
function gemini_call(array $parts, array $opts = []): array {
    $key = GEMINI_API_KEY;
    if (!$key) return ['ok'=>false,'err'=>'GEMINI_API_KEY belum di-set','text'=>null,'raw'=>[]];

    $body = [
        'contents' => [[ 'role'=>'user', 'parts'=>$parts ]],
        'generationConfig' => [
            'temperature'      => $opts['temperature'] ?? 0.4,
            'maxOutputTokens'  => $opts['max_tokens']  ?? 1024,
        ],
    ];
    if (!empty($opts['json'])) {
        $body['generationConfig']['responseMimeType'] = 'application/json';
    }
    if (!empty($opts['system'])) {
        $body['systemInstruction'] = ['role'=>'system','parts'=>[['text'=>$opts['system']]]];
    }

    // Revisi 16 Juni 2026 — dukung dua jenis kredensial:
    //  (a) API key biasa (diawali "AIza..."): dikirim via query ?key=
    //  (b) OAuth 2 access token: dikirim via header Authorization: Bearer
    $isApiKey = (strncmp($key, 'AIza', 4) === 0);
    $base = 'https://generativelanguage.googleapis.com/v1beta/models/'.GEMINI_MODEL.':generateContent';
    $headers = ['Content-Type: application/json'];
    if ($isApiKey) {
        $url = $base.'?key='.urlencode($key);
    } else {
        $url = $base;
        $headers[] = 'Authorization: Bearer '.$key;
    }
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($body, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER     => $headers,
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($res === false) return ['ok'=>false,'err'=>'curl: '.$err,'text'=>null,'raw'=>[]];
    $j = json_decode($res, true);
    if ($code !== 200) {
        $msg = $j['error']['message'] ?? ('HTTP '.$code);
        // Pesan lebih ramah untuk kasus key salah / token kedaluwarsa.
        if (stripos($msg, 'invalid authentication') !== false
            || stripos($msg, 'API key not valid') !== false
            || stripos($msg, 'API_KEY_INVALID') !== false) {
            $msg = 'Kredensial Gemini tidak valid. Set environment variable '
                 . 'GEMINI_API_KEY berisi API key dari https://aistudio.google.com/apikey '
                 . '(diawali "AIza..."), lalu restart server. Detail: '.$msg;
        }
        return ['ok'=>false,'err'=>$msg,'text'=>null,'raw'=>$j ?: []];
    }
    $text = '';
    foreach (($j['candidates'][0]['content']['parts'] ?? []) as $p) {
        if (isset($p['text'])) $text .= $p['text'];
    }
    return ['ok'=>true,'err'=>null,'text'=>trim($text),'raw'=>$j];
}

/** Versi convenience untuk teks-saja. */
function gemini_text(string $prompt, array $opts = []): array {
    return gemini_call([['text'=>$prompt]], $opts);
}

/** Versi convenience untuk teks + 1 gambar lokal. */
function gemini_vision(string $prompt, string $imagePath, array $opts = []): array {
    if (!is_file($imagePath)) return ['ok'=>false,'err'=>'file gambar tidak ada','text'=>null,'raw'=>[]];
    $mime = mime_content_type($imagePath) ?: 'image/jpeg';
    $b64  = base64_encode(file_get_contents($imagePath));
    return gemini_call([
        ['text'=>$prompt],
        ['inline_data'=>['mime_type'=>$mime,'data'=>$b64]],
    ], $opts);
}

/** Ekstrak JSON object pertama dari respons text bebas. */
function gemini_extract_json(?string $text): ?array {
    if (!$text) return null;
    if (preg_match('/\{[\s\S]*\}/', $text, $m)) {
        $obj = json_decode($m[0], true);
        if (is_array($obj)) return $obj;
    }
    return null;
}