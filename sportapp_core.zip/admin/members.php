<?php
require __DIR__.'/../config/db.php';
require __DIR__.'/../includes/auth.php';
require __DIR__.'/../includes/helpers.php';
require_role('admin');
$pageTitle='Manajemen Member';
// Revisi 6 Juni 2026 — idempotent migration kolom koordinator_id
// Revisi 14 Juni 2026 — kolom aktif (BOOLEAN) untuk status member aktif/nonaktif
// Revisi R6 (Juli 2026) — kolom username, komunitas_id, paket untuk CRUD di admin.
try { db_exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS aktif BOOLEAN DEFAULT TRUE"); } catch (Throwable $e) {}
try { db_exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS nonaktif_catatan TEXT"); } catch (Throwable $e) {}
try { db_exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(40)"); } catch (Throwable $e) {}
try { db_exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS komunitas_id INTEGER"); } catch (Throwable $e) {}
try { db_exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS paket VARCHAR(20) DEFAULT 'gratis'"); } catch (Throwable $e) {}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $a = $_POST['_action'] ?? '';
    if ($a==='update_role') {
        db_exec("UPDATE users SET role=$1 WHERE id=$2", [$_POST['role'], (int)$_POST['id']]);
    } elseif ($a==='update_pic') {
        $pic = ($_POST['pic_admin_id'] ?? '') !== '' ? (int)$_POST['pic_admin_id'] : null;
        db_exec("UPDATE users SET pic_admin_id=$1 WHERE id=$2", [$pic, (int)$_POST['id']]);
    } elseif ($a==='toggle_aktif') {
        // Revisi 20 Juni 2026 — deteksi tipe kolom `aktif` (SMALLINT vs BOOLEAN)
        // agar tidak terjadi "invalid input syntax for type smallint: 'f'".
        $aktif = ((int)($_POST['aktif'] ?? 1)) === 1;
        $catatan = trim($_POST['nonaktif_catatan'] ?? '') ?: null;
        $dt = (string) db_val("SELECT data_type FROM information_schema.columns WHERE table_schema='public' AND table_name='users' AND column_name='aktif'");
        $isBool = stripos($dt, 'bool') !== false;
        $val = $isBool ? ($aktif ? 't' : 'f') : ($aktif ? 1 : 0);
        try {
          db_exec("UPDATE users SET aktif=$1, nonaktif_catatan=$2 WHERE id=$3",
                  [$val, $aktif ? null : $catatan, (int)$_POST['id']]);
        } catch (Throwable $e) {
          // fallback: coba tipe lain
          $val2 = $isBool ? ($aktif ? 1 : 0) : ($aktif ? 't' : 'f');
          db_exec("UPDATE users SET aktif=$1, nonaktif_catatan=$2 WHERE id=$3",
                  [$val2, $aktif ? null : $catatan, (int)$_POST['id']]);
        }
        // Bersihkan pesan error stale dari sesi sebelumnya (jika ada),
        // supaya tidak salah ditampilkan setelah redirect.
        unset($_SESSION['error_popup']);
        $_SESSION['flash'] = $aktif ? 'Member berhasil diaktifkan.' : 'Member berhasil di-nonaktifkan.';
    } elseif ($a==='delete') {
        db_exec("DELETE FROM users WHERE id=$1", [(int)$_POST['id']]);
    } elseif ($a==='create') {
        $pwd = $_POST['password'] ?: 'changeme';
        $jk = in_array(($_POST['jenis_kelamin'] ?? ''), ['L','P'], true) ? $_POST['jenis_kelamin'] : null;
        $wa = trim($_POST['wa'] ?? '') ?: null;
        // Revisi R6 (Juli 2026) — Tambah username, komunitas_id, paket.
        $username = trim($_POST['username'] ?? '') ?: null;
        $komId = ($_POST['komunitas_id'] ?? '') !== '' ? (int)$_POST['komunitas_id'] : null;
        $paket = in_array(($_POST['paket'] ?? 'gratis'), ['gratis','pro','komunitas'], true) ? $_POST['paket'] : 'gratis';
        try {
            db_exec("INSERT INTO users(nama,email,password_hash,role,jenis_kelamin,wa,username,komunitas_id,paket)
                     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)",
                    [$_POST['nama'], $_POST['email'], password_hash($pwd, PASSWORD_BCRYPT), $_POST['role'], $jk, $wa, $username, $komId, $paket]);
            $_SESSION['flash'] = 'Member baru ditambahkan.';
        } catch (Throwable $e) {
            $_SESSION['flash_err'] = 'Gagal menambah member: '.$e->getMessage();
        }
    } elseif ($a==='reset_pwd') {
        $new = $_POST['new_password'] ?? '';
        if (strlen($new) >= 6) {
            db_exec("UPDATE users SET password_hash=$1 WHERE id=$2",
                    [password_hash($new, PASSWORD_BCRYPT), (int)$_POST['id']]);
            $_SESSION['flash'] = 'Password member berhasil diubah.';
        } else { $_SESSION['flash_err'] = 'Password minimal 6 karakter.'; }
    } elseif ($a==='edit') {
        $jk = in_array(($_POST['jenis_kelamin'] ?? ''), ['L','P'], true) ? $_POST['jenis_kelamin'] : null;
        $wa = trim($_POST['wa'] ?? '') ?: null;
        // Revisi R6 (Juli 2026) — Edit username, komunitas_id, paket.
        $username = trim($_POST['username'] ?? '') ?: null;
        $komId = ($_POST['komunitas_id'] ?? '') !== '' ? (int)$_POST['komunitas_id'] : null;
        $paket = in_array(($_POST['paket'] ?? 'gratis'), ['gratis','pro','komunitas'], true) ? $_POST['paket'] : 'gratis';
        db_exec("UPDATE users SET nama=$1, email=$2, jenis_kelamin=$3, wa=$4, username=$5, komunitas_id=$6, paket=$7 WHERE id=$8",
                [$_POST['nama'], $_POST['email'], $jk, $wa, $username, $komId, $paket, (int)$_POST['id']]);
        $_SESSION['flash'] = 'Data member diperbarui.';
    } elseif ($a==='upload_foto') {
        $id = (int)$_POST['id'];
        $target = db_one("SELECT * FROM users WHERE id=$1", [$id]);
        if (!$target) {
            $_SESSION['flash_err'] = 'Member tidak ditemukan.';
        } elseif (empty($_FILES['foto']) || empty($_FILES['foto']['tmp_name']) || ($_FILES['foto']['error'] ?? 1) !== 0) {
            $errCode = $_FILES['foto']['error'] ?? 'tidak ada file';
            $_SESSION['flash_err'] = 'Upload foto gagal (error: '.$errCode.'). Cek ukuran file & upload_max_filesize.';
        } else {
            try {
                require_once __DIR__.'/../config/imagekit.php';
                global $imageKit;
                $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION)) ?: 'jpg';
                $safe = preg_replace('/[^a-z0-9]/i','_',$target['nama'])."-avatar-".time().".".$ext;
                $up = $imageKit->uploadFile([
                    'file' => base64_encode(file_get_contents($_FILES['foto']['tmp_name'])),
                    'fileName' => $safe,
                    'folder' => '/sportapp/avatar'
                ]);
                if (!empty($up->error)) {
                    $em = is_object($up->error) ? ($up->error->message ?? json_encode($up->error)) : (string)$up->error;
                    $_SESSION['flash_err'] = 'ImageKit menolak upload: '.$em;
                } else {
                    if (!empty($target['foto_file_id'])) { try { $imageKit->deleteFile($target['foto_file_id']); } catch(Throwable $e){} }
                    db_exec("UPDATE users SET foto_url=$1, foto_file_id=$2 WHERE id=$3",
                            [$up->result->url, $up->result->fileId, $id]);
                    $_SESSION['flash'] = 'Foto profil member berhasil diperbarui.';
                }
            } catch (Throwable $e) {
                $_SESSION['flash_err'] = 'Upload foto gagal: '.$e->getMessage();
            }
        }
        unset($_SESSION['error_popup']);
    } elseif ($a==='delete_foto') {
        $id = (int)$_POST['id'];
        $target = db_one("SELECT foto_file_id FROM users WHERE id=$1", [$id]);
        if ($target && !empty($target['foto_file_id'])) {
            require_once __DIR__.'/../config/imagekit.php';
            global $imageKit;
            try { $imageKit->deleteFile($target['foto_file_id']); } catch(Throwable $e){}
        }
        db_exec("UPDATE users SET foto_url=NULL, foto_file_id=NULL WHERE id=$1", [$id]);
    }
    header('Location: members.php'); exit;
}

$users = db_all("SELECT u.*, p.nama AS pic_nama, k.nama AS komunitas_nama
                 FROM users u
                 LEFT JOIN users p ON p.id = u.pic_admin_id
                 LEFT JOIN komunitas k ON k.id = u.komunitas_id
                 ORDER BY u.role, u.nama");
$admins = db_all("SELECT id, nama FROM users WHERE role='admin' ORDER BY nama");
// Revisi R6 (Juli 2026) — daftar komunitas untuk dropdown CRUD member.
$komList = [];
try { $komList = db_all("SELECT id, nama FROM komunitas WHERE aktif=1 ORDER BY nama"); } catch (Throwable $e) {}
$paketOpts = ['gratis'=>'🆓 Gratis','pro'=>'⭐ Pro','komunitas'=>'👥 Komunitas'];
// Revisi 14 Juni 2026 — kolom Koordinator Penghubung dihapus, auto-create akun dummy dihapus.
$flash = $_SESSION['flash'] ?? null; $flashE = $_SESSION['flash_err'] ?? null;
unset($_SESSION['flash'], $_SESSION['flash_err']);
include __DIR__.'/../includes/header.php'; ?>

<h2 class="mb-3"><i class="bi bi-people text-primary"></i> Manajemen Member</h2>

<?php if($flash): ?><div class="alert alert-success py-2"><?= htmlspecialchars($flash) ?></div><?php endif; ?>
<?php if($flashE): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($flashE) ?></div><?php endif; ?>

<?php /* Revisi R6 (Juli 2026) — Tambah Member sebagai spoiler (collapse) + field Komunitas & Paket Member. */ ?>
<div class="card shadow-sm mb-3">
  <div class="card-header d-flex justify-content-between align-items-center">
    <span><i class="bi bi-person-plus me-1 text-primary"></i> Tambah Member</span>
    <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#addMemberSpoiler" aria-expanded="false" aria-controls="addMemberSpoiler">
      <i class="bi bi-plus-lg"></i> Buka Form
    </button>
  </div>
  <div id="addMemberSpoiler" class="collapse">
    <div class="card-body">
      <form method="post" class="row g-2">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="_action" value="create">
        <div class="col-md-3"><label class="form-label small mb-0">Nama Lengkap *</label>
          <input class="form-control form-control-sm" name="nama" required></div>
        <div class="col-md-3"><label class="form-label small mb-0">Email *</label>
          <input class="form-control form-control-sm" type="email" name="email" required></div>
        <div class="col-md-2"><label class="form-label small mb-0">Username</label>
          <input class="form-control form-control-sm" name="username" placeholder="mis. budi_88"></div>
        <div class="col-md-2"><label class="form-label small mb-0">Password</label>
          <input class="form-control form-control-sm" name="password" placeholder="default: changeme"></div>
        <div class="col-md-2"><label class="form-label small mb-0">No. WhatsApp</label>
          <input class="form-control form-control-sm" name="wa" placeholder="08xxxxxxxxxx"></div>
        <div class="col-md-1"><label class="form-label small mb-0">JK</label>
          <select class="form-select form-select-sm" name="jenis_kelamin"><option value="">—</option><option value="L">L</option><option value="P">P</option></select></div>
        <div class="col-md-2"><label class="form-label small mb-0">Role</label>
          <select class="form-select form-select-sm" name="role"><option value="member">member</option><option value="admin">admin</option></select></div>
        <div class="col-md-4"><label class="form-label small mb-0"><i class="bi bi-people-fill text-success"></i> Komunitas</label>
          <select class="form-select form-select-sm" name="komunitas_id">
            <option value="">— Tidak berkomunitas —</option>
            <?php foreach($komList as $k): ?>
              <option value="<?= (int)$k['id'] ?>"><?= htmlspecialchars($k['nama']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="col-md-3"><label class="form-label small mb-0"><i class="bi bi-award text-warning"></i> Paket Member</label>
          <select class="form-select form-select-sm" name="paket">
            <?php foreach($paketOpts as $pk=>$pl): ?>
              <option value="<?= $pk ?>" <?= $pk==='gratis'?'selected':'' ?>><?= htmlspecialchars($pl) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="col-12"><button class="btn btn-primary btn-sm"><i class="bi bi-save"></i> Simpan Member Baru</button></div>
      </form>
    </div>
  </div>
</div>

<div class="card shadow-sm">
  <div class="card-header d-flex flex-wrap gap-2 justify-content-between align-items-center">
    <span><i class="bi bi-table"></i> Daftar Member</span>
    <div class="d-flex gap-2 align-items-center">
      <input id="memberSearch" class="form-control form-control-sm" style="max-width:220px" placeholder="🔍 Cari nama / email...">
      <select id="memberPageSize" class="form-select form-select-sm" style="max-width:110px">
        <option value="10">10 / hal</option>
        <option value="25" selected>25 / hal</option>
        <option value="50">50 / hal</option>
        <option value="100">100 / hal</option>
      </select>
    </div>
  </div>
  <div class="table-responsive"><table class="table table-hover mb-0 align-middle" id="memberTable" data-paginate="10">
  <thead><tr><th>#</th><th>Nama</th><th>Username</th><th>Email</th><th>WA</th><th>JK</th><th>Komunitas</th><th>Paket</th><th>PIC Admin</th><th>Role</th><th>Aktif</th><th>Status</th><th class="text-end">Aksi</th></tr></thead><tbody>
  <?php foreach($users as $i=>$u): $on = is_online($u['last_seen'] ?? null);
    $waDigits = preg_replace('/\D+/', '', $u['wa'] ?? '');
    if ($waDigits && str_starts_with($waDigits, '0')) $waDigits = '62'.substr($waDigits,1);
  ?>
    <tr data-search="<?= htmlspecialchars(strtolower(($u['nama'] ?? '').' '.($u['email'] ?? '').' '.($u['username'] ?? ''))) ?>">
      <td class="text-muted row-num"><?= $i+1 ?></td>
      <td class="fw-semibold"><?= user_name_with_avatar($u['foto_url'] ?? null, $u['nama'], $on, 32) ?></td>
      <td class="small"><?= $u['username'] ? '<span class="badge bg-light text-dark border">@'.htmlspecialchars($u['username']).'</span>' : '<span class="text-muted">—</span>' ?></td>
      <td class="text-muted small"><?= htmlspecialchars($u['email']) ?></td>
      <td><?= $u['wa'] ? '<span class="small">'.htmlspecialchars($u['wa']).'</span>' : '<span class="text-muted small">—</span>' ?></td>
      <td><?php $jk=$u['jenis_kelamin']??null; echo $jk==='L'?'<span class="pill">L</span>':($jk==='P'?'<span class="pill">P</span>':'<span class="text-muted small">—</span>'); ?></td>
      <td class="small"><?= !empty($u['komunitas_nama']) ? '<span class="badge bg-success-subtle text-success"><i class="bi bi-people-fill"></i> '.htmlspecialchars($u['komunitas_nama']).'</span>' : '<span class="text-muted">—</span>' ?></td>
      <td><?php $pk = strtolower((string)($u['paket'] ?? 'gratis')); $pmap=['gratis'=>['secondary','🆓'],'pro'=>['warning','⭐ Pro'],'komunitas'=>['success','👥 Kom']]; $pb=$pmap[$pk]??$pmap['gratis']; ?>
        <span class="badge bg-<?= $pb[0] ?>"><?= $pb[1] ?></span></td>
      <td>
        <form method="post" class="d-flex">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <input type="hidden" name="_action" value="update_pic">
          <input type="hidden" name="id" value="<?= $u['id'] ?>">
          <select name="pic_admin_id" class="form-select form-select-sm" onchange="this.form.submit()" style="min-width:130px">
            <option value="">— belum —</option>
            <?php foreach($admins as $ad): ?>
              <option value="<?= (int)$ad['id'] ?>" <?= (string)$u['pic_admin_id']===(string)$ad['id']?'selected':'' ?>><?= htmlspecialchars($ad['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </form>
      </td>
      <td>
        <form method="post" class="d-flex gap-1">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <input type="hidden" name="_action" value="update_role">
          <input type="hidden" name="id" value="<?= $u['id'] ?>">
          <select name="role" class="form-select form-select-sm" onchange="this.form.submit()">
            <?php foreach(['publik','member','admin'] as $r): ?><option <?= $u['role']===$r?'selected':'' ?>><?= $r ?></option><?php endforeach; ?>
          </select>
        </form>
      </td>
      <td>
        <?php
          $_aktifRaw = $u['aktif'] ?? null;
          $_aktifBool = ($_aktifRaw === null) ? true : in_array(strtolower((string)$_aktifRaw), ['1','t','true','y','yes'], true);
        ?>
        <?php if ($_aktifBool): ?>
          <form method="post" class="d-inline" onsubmit="return confirm('Non-aktifkan <?= htmlspecialchars($u['nama']) ?>?')">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="_action" value="toggle_aktif">
            <input type="hidden" name="id" value="<?= $u['id'] ?>">
            <input type="hidden" name="aktif" value="0">
            <input type="hidden" name="nonaktif_catatan" value="Dinonaktifkan oleh admin">
            <button class="btn btn-sm btn-success" title="Klik untuk non-aktifkan"><i class="bi bi-person-check-fill"></i> Aktif</button>
          </form>
        <?php else: ?>
          <form method="post" class="d-inline">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="_action" value="toggle_aktif">
            <input type="hidden" name="id" value="<?= $u['id'] ?>">
            <input type="hidden" name="aktif" value="1">
            <button class="btn btn-sm btn-outline-danger" title="Klik untuk aktifkan kembali"><i class="bi bi-person-x-fill"></i> Nonaktif</button>
          </form>
        <?php endif; ?>
      </td>
      <td><?= $on ? '<span class="badge bg-success">Online</span>' : '<span class="badge bg-secondary">Offline</span>' ?></td>
      <td class="text-end text-nowrap">
        <?php if($waDigits): ?>
          <a href="https://wa.me/<?= htmlspecialchars($waDigits) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-success" title="Hubungi via WhatsApp"><i class="bi bi-whatsapp"></i></a>
        <?php else: ?>
          <button class="btn btn-sm btn-outline-secondary" disabled title="No. WA belum diisi"><i class="bi bi-whatsapp"></i></button>
        <?php endif; ?>
        <button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#foto<?= $u['id'] ?>" title="Foto"><i class="bi bi-image"></i></button>
        <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#pwd<?= $u['id'] ?>" title="Reset Password"><i class="bi bi-key"></i></button>
        <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#edt<?= $u['id'] ?>" title="Edit"><i class="bi bi-pencil"></i></button>
        <form method="post" class="d-inline" onsubmit="return confirm('Hapus user <?= htmlspecialchars($u['nama']) ?>?')">
          <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
          <input type="hidden" name="_action" value="delete">
          <input type="hidden" name="id" value="<?= $u['id'] ?>">
          <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody></table></div>
  <div class="card-footer d-flex flex-wrap gap-2 justify-content-between align-items-center small">
    <div id="memberPageInfo" class="text-muted"></div>
    <nav><ul class="pagination pagination-sm mb-0" id="memberPager"></ul></nav>
  </div>
</div>

<?php foreach($users as $u): ?>
<div class="modal fade" id="na<?= $u['id'] ?>" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><form method="post" class="modal-content">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="toggle_aktif"><input type="hidden" name="id" value="<?= $u['id'] ?>"><input type="hidden" name="aktif" value="0">
  <div class="modal-header"><h5 class="modal-title"><i class="bi bi-person-x text-danger"></i> Non-aktifkan: <?= htmlspecialchars($u['nama']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body">
    <label class="form-label small fw-semibold">Catatan / Alasan (wajib)</label>
    <textarea name="nonaktif_catatan" class="form-control" rows="3" required placeholder="Misal: pindah domisili, cuti panjang, dst."></textarea>
  </div>
  <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button><button class="btn btn-danger"><i class="bi bi-person-x"></i> Non-aktifkan</button></div>
</form></div></div>

<div class="modal fade" id="foto<?= $u['id'] ?>" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><form method="post" enctype="multipart/form-data" class="modal-content">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= $u['id'] ?>">
  <div class="modal-header"><h5 class="modal-title"><i class="bi bi-image"></i> Foto: <?= htmlspecialchars($u['nama']) ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body text-center">
    <div class="mb-3"><?= user_avatar($u['foto_url'] ?? null, $u['nama'], 96) ?></div>
    <input type="file" name="foto" class="form-control" accept="image/*" required>
    <small class="text-muted">Foto akan diunggah ke ImageKit.</small>
  </div>
  <div class="modal-footer">
    <?php if(!empty($u['foto_url'])): ?>
    <button type="submit" name="_action" value="delete_foto" class="btn btn-outline-danger" onclick="return confirm('Hapus foto?')"><i class="bi bi-trash"></i> Hapus Foto</button>
    <?php endif; ?>
    <button type="submit" name="_action" value="upload_foto" class="btn btn-primary"><i class="bi bi-upload"></i> Upload</button>
  </div>
</form></div></div>

<div class="modal fade" id="pwd<?= $u['id'] ?>" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><form method="post" class="modal-content">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="reset_pwd"><input type="hidden" name="id" value="<?= $u['id'] ?>">
  <div class="modal-header"><h5 class="modal-title"><i class="bi bi-key"></i> Reset Password</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body">
    <label class="form-label small fw-semibold">Password Baru (min 6)</label>
    <input type="text" name="new_password" class="form-control" minlength="6" required>
  </div>
  <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button><button class="btn btn-warning"><i class="bi bi-shield-check"></i> Reset</button></div>
</form></div></div>

<div class="modal fade" id="edt<?= $u['id'] ?>" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><form method="post" class="modal-content">
  <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="edit"><input type="hidden" name="id" value="<?= $u['id'] ?>">
  <div class="modal-header"><h5 class="modal-title"><i class="bi bi-pencil-square"></i> Edit Member</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body">
    <div class="mb-2"><label class="form-label small fw-semibold">Nama</label><input name="nama" class="form-control" value="<?= htmlspecialchars($u['nama']) ?>" required></div>
    <div class="mb-2"><label class="form-label small fw-semibold">Username</label><input name="username" class="form-control" value="<?= htmlspecialchars($u['username'] ?? '') ?>" placeholder="mis. budi_88"></div>
    <div class="mb-2"><label class="form-label small fw-semibold">Email</label><input name="email" type="email" class="form-control" value="<?= htmlspecialchars($u['email']) ?>" required></div>
    <div class="mb-2"><label class="form-label small fw-semibold"><i class="bi bi-whatsapp text-success"></i> No. WhatsApp</label><input name="wa" class="form-control" value="<?= htmlspecialchars($u['wa'] ?? '') ?>" placeholder="08xxxxxxxxxx"></div>
    <div class="mb-2"><label class="form-label small fw-semibold">Jenis Kelamin</label>
      <select class="form-select" name="jenis_kelamin">
        <option value="" <?= empty($u['jenis_kelamin'])?'selected':'' ?>>— Tidak diisi —</option>
        <option value="L" <?= ($u['jenis_kelamin']??'')==='L'?'selected':'' ?>>Laki-laki</option>
        <option value="P" <?= ($u['jenis_kelamin']??'')==='P'?'selected':'' ?>>Perempuan</option>
      </select></div>
    <div class="mb-2"><label class="form-label small fw-semibold"><i class="bi bi-people-fill text-success"></i> Komunitas</label>
      <select class="form-select" name="komunitas_id">
        <option value="">— Tidak berkomunitas —</option>
        <?php foreach($komList as $k): ?>
          <option value="<?= (int)$k['id'] ?>" <?= ((int)($u['komunitas_id']??0)===(int)$k['id'])?'selected':'' ?>><?= htmlspecialchars($k['nama']) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="mb-2"><label class="form-label small fw-semibold"><i class="bi bi-award text-warning"></i> Paket Member</label>
      <select class="form-select" name="paket">
        <?php $cur = strtolower((string)($u['paket'] ?? 'gratis')); foreach($paketOpts as $pk=>$pl): ?>
          <option value="<?= $pk ?>" <?= $cur===$pk?'selected':'' ?>><?= htmlspecialchars($pl) ?></option>
        <?php endforeach; ?>
      </select></div>
  </div>
  <div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button><button class="btn btn-primary"><i class="bi bi-save"></i> Simpan</button></div>
</form></div></div>
<?php endforeach; ?>

<script>
// === Client-side pagination & search untuk tabel member (tanpa reload) ===
(function(){
  var table = document.getElementById('memberTable');
  if(!table) return;
  var rows = Array.from(table.tBodies[0].rows);
  var searchInput = document.getElementById('memberSearch');
  var pageSizeSel = document.getElementById('memberPageSize');
  var pager = document.getElementById('memberPager');
  var info = document.getElementById('memberPageInfo');
  var page = 1;
  function filtered(){
    var q = (searchInput.value||'').toLowerCase().trim();
    return rows.filter(r => !q || (r.dataset.search||'').includes(q));
  }
  function render(){
    var ps = parseInt(pageSizeSel.value,10)||25;
    var data = filtered();
    var total = data.length;
    var pages = Math.max(1, Math.ceil(total/ps));
    if(page>pages) page = pages;
    var start = (page-1)*ps, end = Math.min(start+ps, total);
    rows.forEach(r => r.style.display='none');
    data.slice(start,end).forEach((r,i)=>{
      r.style.display='';
      var c = r.querySelector('.row-num'); if(c) c.textContent = start+i+1;
    });
    info.textContent = total ? ('Menampilkan '+(start+1)+'–'+end+' dari '+total+' member') : 'Tidak ada data';
    // pager
    pager.innerHTML = '';
    function btn(label, p, dis, act){
      var li = document.createElement('li');
      li.className = 'page-item'+(dis?' disabled':'')+(act?' active':'');
      var a = document.createElement('a');
      a.className='page-link'; a.href='#'; a.textContent=label;
      a.addEventListener('click', function(e){e.preventDefault(); if(!dis && !act){ page=p; render(); }});
      li.appendChild(a); pager.appendChild(li);
    }
    btn('«', Math.max(1,page-1), page<=1, false);
    var maxBtn = 7;
    var from = Math.max(1, page - 3), to = Math.min(pages, from + maxBtn - 1);
    from = Math.max(1, to - maxBtn + 1);
    for(var p=from; p<=to; p++) btn(String(p), p, false, p===page);
    btn('»', Math.min(pages,page+1), page>=pages, false);
  }
  searchInput.addEventListener('input', function(){ page=1; render(); });
  pageSizeSel.addEventListener('change', function(){ page=1; render(); });
  render();
})();
</script>

<?php include __DIR__.'/../includes/footer.php'; ?>
