<?php
require __DIR__.'/config/db.php';
require __DIR__.'/includes/auth.php';
require __DIR__.'/includes/security.php';
require __DIR__.'/includes/helpers.php';
require __DIR__.'/includes/notifications.php';
require __DIR__.'/includes/badges.php';
send_security_headers(); enforce_session_timeout();
$pageTitle = 'Beranda';
$u = current_user();

// ---- Handle forum + social feed actions ----
if ($_SERVER['REQUEST_METHOD']==='POST' && $u) {
    csrf_check();
    rate_limit_or_die('post:'.$u['id'], 30, 60);
    $a = $_POST['_action'] ?? '';
    if ($a === 'chat_post') {
        $pesan = trim($_POST['pesan'] ?? '');
        $parent = (int)($_POST['parent_id'] ?? 0) ?: null;
        if ($pesan !== '') {
            $clean = sanitize_html($pesan);
            db_exec("INSERT INTO chat_forum(user_id,pesan,parent_id) VALUES($1,$2,$3)", [(int)$u['id'], $clean, $parent]);
            recompute_badges((int)$u['id']);
        }
    } elseif ($a === 'chat_delete' && $u['role']==='admin') {
        db_exec("DELETE FROM chat_forum WHERE id=$1", [(int)$_POST['id']]);
    } elseif ($a === 'chat_edit') {
        // Pemilik pesan bisa mengedit pesannya sendiri; admin juga bisa
        $cid = (int)$_POST['id'];
        $newPesan = trim($_POST['pesan'] ?? '');
        if ($cid && $newPesan !== '') {
            $own = db_one("SELECT user_id FROM chat_forum WHERE id=$1", [$cid]);
            if ($own && ((int)$own['user_id']===(int)$u['id'] || $u['role']==='admin')) {
                db_exec("UPDATE chat_forum SET pesan=$1, updated_at=now() WHERE id=$2",
                    [sanitize_html($newPesan), $cid]);
            }
        }
    } elseif ($a === 'story_delete' && $u['role']==='admin') {
        $pid = (int)$_POST['post_id'];
        db_exec("DELETE FROM post_comments WHERE post_id=$1", [$pid]);
        db_exec("DELETE FROM post_likes WHERE post_id=$1", [$pid]);
        db_exec("DELETE FROM posts WHERE id=$1 AND jenis='story'", [$pid]);
    } elseif ($a === 'post_delete' && $u['role']==='admin') {
        $pid = (int)$_POST['post_id'];
        db_exec("DELETE FROM post_comments WHERE post_id=$1", [$pid]);
        db_exec("DELETE FROM post_likes WHERE post_id=$1", [$pid]);
        db_exec("DELETE FROM posts WHERE id=$1", [$pid]);
    } elseif ($a === 'comment_delete' && $u['role']==='admin') {
        db_exec("DELETE FROM post_comments WHERE id=$1", [(int)$_POST['comment_id']]);
    } elseif ($a === 'chat_react') {
        $cid = (int)$_POST['chat_id']; $val = (int)$_POST['val'];
        if (!in_array($val, [-1,1], true)) $val = 1;
        // toggle: hapus dulu, lalu insert
        db_exec("DELETE FROM chat_reactions WHERE chat_id=$1 AND user_id=$2", [$cid, (int)$u['id']]);
        db_exec("INSERT INTO chat_reactions(chat_id,user_id,val) VALUES($1,$2,$3)", [$cid, (int)$u['id'], $val]);
    } elseif ($a === 'post_new') {
        $caption = substr(trim($_POST['caption'] ?? ''), 0, 500);
        $jenis = $_POST['jenis'] === 'story' ? 'story' : 'post';
        $fotoUrl = null;
        if (!empty($_FILES['foto']['name'])) {
            [$ok, $extOrErr] = validate_image_upload($_FILES['foto']);
            if ($ok) {
                $name = preg_replace('/[^a-z0-9]/i','_', $u['nama']).'-'.$jenis.'-'.time().'-'.bin2hex(random_bytes(4)).'.'.$extOrErr;
                require_once __DIR__.'/config/imagekit.php';
                global $imageKit;
                try {
                    $uploadFile = $imageKit->uploadFile([
                        'file' => base64_encode(file_get_contents($_FILES['foto']['tmp_name'])),
                        'fileName' => $name,
                        'folder' => '/sportapp/social/'.date('F_Y'),
                    ]);
                    if (!$uploadFile->error) {
                        $fotoUrl = $uploadFile->result->url;
                    }
                } catch (Throwable $e) { /* fail silently, post tanpa foto */ }
            }
        }
        if ($jenis === 'story') {
            db_exec("INSERT INTO posts(user_id,caption,foto_url,jenis,expired_at) VALUES($1,$2,$3,$4, now() + interval '24 hours')",
                [(int)$u['id'], htmlspecialchars($caption), $fotoUrl, $jenis]);
        } else {
            db_exec("INSERT INTO posts(user_id,caption,foto_url,jenis,expired_at) VALUES($1,$2,$3,$4, NULL)",
                [(int)$u['id'], htmlspecialchars($caption), $fotoUrl, $jenis]);
        }
    } elseif ($a === 'like') {
        $pid = (int)$_POST['post_id'];
        try { db_exec("INSERT INTO post_likes(post_id,user_id) VALUES($1,$2) ON CONFLICT DO NOTHING", [$pid, (int)$u['id']]); } catch (Throwable $e) {}
    } elseif ($a === 'comment') {
        $pid = (int)$_POST['post_id'];
        $isi = substr(trim($_POST['isi'] ?? ''), 0, 300);
        if ($isi !== '') db_exec("INSERT INTO post_comments(post_id,user_id,isi) VALUES($1,$2,$3)", [$pid, (int)$u['id'], $isi]);
    }
    header('Location: /index.php#feed'); exit;
}

$totalSesi    = (int) db_val("SELECT COUNT(*) FROM jadwal");
$totalHadir   = (int) db_val("SELECT COUNT(*) FROM absensi WHERE hadir=1");
$totalMember  = (int) db_val("SELECT COUNT(*) FROM users WHERE role IN ('member','admin')");

$jadwalTerdekat = db_all("SELECT j.*, u.nama AS koordinator, u.foto_url AS koord_foto, t.nama AS tim_nama
                          FROM jadwal j LEFT JOIN users u ON u.id=j.koordinator_id LEFT JOIN tim t ON t.id=j.tim_id
                          WHERE tanggal >= CURRENT_DATE ORDER BY tanggal ASC LIMIT 5");
$onlineMembers = db_all("SELECT id, nama, foto_url, last_seen FROM users
                         WHERE last_seen IS NOT NULL AND last_seen >= NOW() - INTERVAL '2 minutes' ORDER BY nama");

// Forum: ambil top-level + replies, plus aggregate like/dislike
$chats = db_all("SELECT c.*, u.nama, u.foto_url,
                   COALESCE((SELECT SUM(CASE WHEN val=1 THEN 1 ELSE 0 END) FROM chat_reactions r WHERE r.chat_id=c.id),0) AS likes,
                   COALESCE((SELECT SUM(CASE WHEN val=-1 THEN 1 ELSE 0 END) FROM chat_reactions r WHERE r.chat_id=c.id),0) AS dislikes
                 FROM chat_forum c LEFT JOIN users u ON u.id=c.user_id
                 ORDER BY c.created_at DESC LIMIT 60");
// kelompokkan reply per parent
$top = []; $replies = [];
foreach ($chats as $c) {
    if (empty($c['parent_id'])) $top[] = $c;
    else $replies[(int)$c['parent_id']][] = $c;
}

// Social feed
$stories = db_all("SELECT p.*, u.nama, u.foto_url AS user_foto FROM posts p JOIN users u ON u.id=p.user_id
                   WHERE p.jenis='story' AND (p.expired_at IS NULL OR p.expired_at > now())
                   ORDER BY p.created_at DESC LIMIT 20");
$uidMe = (int)($u['id'] ?? 0);
$feed = db_all("SELECT p.id, p.user_id, p.caption, p.foto_url AS post_foto, p.jenis, p.created_at,
                  u.nama, u.foto_url AS user_foto,
                  (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id=p.id) AS likes,
                  (SELECT COUNT(*) FROM post_comments pc WHERE pc.post_id=p.id) AS comments,
                  (SELECT COUNT(*) FROM post_likes pl2 WHERE pl2.post_id=p.id AND pl2.user_id=$1) AS liked_by_me
                FROM posts p JOIN users u ON u.id=p.user_id
                WHERE p.jenis='post' ORDER BY p.created_at DESC LIMIT 12", [$uidMe]);

// Komentar per post (untuk ditampilkan inline)
$feedIds = array_map(fn($x)=>(int)$x['id'], $feed);
$commentsByPost = [];
if ($feedIds) {
    $rows = db_all("SELECT pc.id, pc.post_id, pc.isi, pc.created_at, u.nama, u.foto_url
                    FROM post_comments pc JOIN users u ON u.id=pc.user_id
                    WHERE pc.post_id = ANY($1::int[]) ORDER BY pc.created_at ASC", ['{'.implode(',', $feedIds).'}']);
    foreach ($rows as $r) $commentsByPost[(int)$r['post_id']][] = $r;
}

$activeQr = db_all("SELECT q.token, j.id, j.tanggal, j.jenis, j.tempat
                    FROM qr_tokens q JOIN jadwal j ON j.id=q.jadwal_id
                    WHERE q.valid_until > now() AND q.valid_from <= now()
                    ORDER BY q.id DESC LIMIT 3");

include __DIR__.'/includes/header.php'; ?>

<section class="hero mb-3 p-3 p-md-4 rounded-3 text-white" style="background:linear-gradient(135deg,#0ea5e9,#6366f1);box-shadow:0 6px 18px rgba(14,165,233,.25);">
  <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
    <span class="badge-soft" style="background:rgba(255,255,255,.18);color:#fff;"><i class="bi bi-stars me-1"></i> Komunitas HapFam</span>
  </div>
  <h1 class="h3 mb-1 text-white" style="line-height:1.25;word-break:break-word;">Dashboard Olahraga Komunitas</h1>
  <p class="mb-2 text-white-50" style="line-height:1.5;">Check-in, kompetisi, dan komunitas dalam satu tempat.</p>
  <button id="installBtn" class="btn btn-sm btn-light fw-semibold"><i class="bi bi-phone"></i> Tambahkan Pintasan ke HP kamu</button>
</section>
<script>
let _deferredInstall = null;
const _installBtn = document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); _deferredInstall = e; });
document.addEventListener('DOMContentLoaded', () => {
  if (!_installBtn) return;
  _installBtn.addEventListener('click', async () => {
    if (_deferredInstall) { _deferredInstall.prompt(); _deferredInstall = null; }
    else { alert('Buka menu browser (⋮) lalu pilih "Tambahkan ke Layar Utama / Install app". Setelah itu, ikon HapFam akan muncul di home screen HP kamu.'); }
  });
});
</script>

<?php if ($u): ?>
<div class="card shadow-sm mb-3 border-0" style="background:linear-gradient(135deg,#0ea5e9,#6366f1);color:#fff;">
  <div class="card-body d-flex align-items-center gap-3 flex-wrap">
    <div style="font-size:2rem"><i class="bi bi-qr-code-scan"></i></div>
    <div class="flex-grow-1">
      <div class="fw-bold">QR Check-in Sesi Olahraga</div>
      <small>Scan QR di lokasi, sistem otomatis catat hadir + validasi GPS.</small>
    </div>
    <a href="/checkin.php" class="btn btn-light fw-semibold"><i class="bi bi-camera"></i> Scan QR</a>
  </div>
  <?php if($activeQr): ?>
  <div class="card-body pt-0">
    <div class="swipe-row">
      <?php foreach($activeQr as $aq):
        $_qrImg = 'https://api.qrserver.com/v1/create-qr-code/?size=400x400&data='.urlencode($aq['token']);
      ?>
        <a href="#" onclick="event.preventDefault();showQR('<?= htmlspecialchars($aq['token'],ENT_QUOTES) ?>','<?= htmlspecialchars($aq['jenis'],ENT_QUOTES) ?>','<?= htmlspecialchars($aq['tanggal'],ENT_QUOTES) ?>','<?= htmlspecialchars($aq['tempat'],ENT_QUOTES) ?>')" class="swipe-card text-decoration-none" style="background:#ffffff22;color:#fff;flex-basis:240px;">
          <div class="p-3">
            <div class="small opacity-75"><?= htmlspecialchars($aq['tanggal']) ?></div>
            <div class="fw-bold"><?= htmlspecialchars($aq['jenis']) ?></div>
            <div class="small"><i class="bi bi-geo-alt"></i> <?= htmlspecialchars($aq['tempat']) ?></div>
            <div class="mt-2"><span class="badge bg-light text-dark"><i class="bi bi-qr-code"></i> Klik untuk lihat QR</span></div>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="row g-3 mb-3">
  <div class="col-6 col-lg-3"><div class="card card-stat shadow-sm"><div class="card-body">
    <div class="stat-icon"><i class="bi bi-calendar-event"></i></div>
    <div class="stat-label">Total Sesi</div><div class="stat-value"><?= $totalSesi ?></div></div></div></div>
  <div class="col-6 col-lg-3"><div class="card card-stat shadow-sm"><div class="card-body">
    <div class="stat-icon"><i class="bi bi-check2-circle"></i></div>
    <div class="stat-label">Total Hadir</div><div class="stat-value"><?= $totalHadir ?></div></div></div></div>
  <div class="col-6 col-lg-3"><div class="card card-stat shadow-sm"><div class="card-body">
    <div class="stat-icon"><i class="bi bi-people-fill"></i></div>
    <div class="stat-label">Member</div><div class="stat-value"><?= $totalMember ?></div></div></div></div>
  <div class="col-6 col-lg-3"><div class="card card-stat shadow-sm"><div class="card-body">
    <div class="stat-icon"><i class="bi bi-broadcast"></i></div>
    <div class="stat-label">Online</div><div class="stat-value"><?= count($onlineMembers) ?></div></div></div></div>
</div>

<?php if($u): ?>
<div class="card shadow-sm mb-3" id="feed"><div class="card-header d-flex justify-content-between">
  <span><i class="bi bi-collection-play text-primary"></i> Story Hari Ini</span>
  <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#postModal"><i class="bi bi-plus-lg"></i> Posting</button>
</div>
<div class="card-body">
  <div class="story-strip" data-live="stories">
    <?php foreach($stories as $s):
      $sFotoDisp = $s['foto_url'] ? ltrim($s['foto_url'],'/') : '';
    ?>
      <div class="story-item position-relative" style="cursor:pointer">
        <div onclick='showStory(<?= json_encode([
          "nama"=>$s["nama"],"foto"=>$sFotoDisp,"user_foto"=>$s["user_foto"] ?? "",
          "caption"=>$s["caption"] ?? "","created_at"=>$s["created_at"] ?? "",
        ], JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE) ?>)'>
          <div class="story-ring">
            <?php if ($sFotoDisp): ?>
              <img src="<?= htmlspecialchars($sFotoDisp) ?>" alt="story" onerror="this.style.display='none'">
            <?php elseif ($s['caption']): ?>
              <div title="<?= htmlspecialchars($s['caption']) ?>"><?= htmlspecialchars(mb_substr($s['nama'],0,1)) ?></div>
            <?php else: ?><div><?= htmlspecialchars(mb_substr($s['nama'],0,1)) ?></div><?php endif; ?>
          </div>
          <small><?= htmlspecialchars($s['nama']) ?></small>
        </div>
        <?php if($u && $u['role']==='admin'): ?>
          <form method="post" class="position-absolute" style="top:-4px;right:-4px;z-index:5;" onsubmit="event.stopPropagation();return confirm('Hapus story ini?')">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
            <input type="hidden" name="_action" value="story_delete">
            <input type="hidden" name="post_id" value="<?= (int)$s['id'] ?>">
            <button class="btn btn-sm btn-danger rounded-circle p-1" style="width:24px;height:24px;line-height:1;" title="Hapus story (admin)"><i class="bi bi-x" style="font-size:.8rem"></i></button>
          </form>
        <?php endif; ?>
      </div>
    <?php endforeach; if(!$stories): ?><div class="text-muted small">Belum ada story.</div><?php endif; ?>
  </div>
</div></div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="card shadow-sm mb-3"><div class="card-header"><i class="bi bi-calendar3 me-1 text-primary"></i> Jadwal Terdekat</div>
      <div class="table-responsive"><table class="table table-hover table-stack mb-0">
        <thead><tr><th>Tanggal</th><th>Jenis</th><th>Tempat</th><th>Koordinator</th></tr></thead><tbody>
        <?php foreach($jadwalTerdekat as $j): ?>
          <tr>
            <td data-label="Tanggal"><?= htmlspecialchars($j['tanggal']) ?></td>
            <td data-label="Jenis"><span class="pill"><?= htmlspecialchars($j['jenis']) ?></span></td>
            <td data-label="Tempat"><i class="bi bi-geo-alt text-muted"></i> <?= htmlspecialchars($j['tempat']) ?></td>
            <td data-label="Koord"><a class="text-decoration-none" href="/user.php?id=<?= (int)$j['koordinator_id'] ?>"><?= user_name_with_avatar($j['koord_foto'] ?? null, $j['koordinator'] ?? '-', false, 24) ?></a></td>
          </tr>
        <?php endforeach; ?>
        </tbody></table></div>
    </div>

    <div class="card shadow-sm"><div class="card-header d-flex justify-content-between"><span><i class="bi bi-images text-primary"></i> Social Feed</span><button class="btn btn-sm btn-link p-0" data-soft-refresh title="Muat data terbaru"><i class="bi bi-arrow-clockwise"></i></button></div>
     <div class="card-body" data-live="feed">
      <?php foreach($feed as $p): ?>
        <div class="border-bottom pb-3 mb-3" id="post-<?= (int)$p['id'] ?>">
          <div class="d-flex align-items-center gap-2 mb-2">
            <a href="/user.php?id=<?= (int)$p['user_id'] ?>" class="text-decoration-none"><?= user_avatar($p['user_foto'] ?? null, $p['nama'], 32) ?></a>
            <a href="/user.php?id=<?= (int)$p['user_id'] ?>" class="text-decoration-none fw-semibold"><?= htmlspecialchars($p['nama']) ?></a>
            <small class="text-muted ms-auto"><?= date('d M H:i', strtotime($p['created_at'])) ?></small>
            <?php if($u && $u['role']==='admin'): ?>
              <form method="post" class="d-inline" onsubmit="return confirm('Hapus postingan ini?')">
                <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                <input type="hidden" name="_action" value="post_delete">
                <input type="hidden" name="post_id" value="<?= (int)$p['id'] ?>">
                <button class="btn btn-sm btn-link text-danger p-0" title="Hapus postingan (admin)"><i class="bi bi-trash"></i></button>
              </form>
            <?php endif; ?>
          </div>
          <?php if(!empty($p['post_foto'])): $pfDisp = ltrim($p['post_foto'],'/'); ?><img src="<?= htmlspecialchars($pfDisp) ?>" class="img-fluid rounded mb-2" style="max-height:400px;" onerror="this.style.display='none'"><?php endif; ?>
          <div class="mb-2"><?= nl2br(htmlspecialchars($p['caption'] ?? '')) ?></div>
          <div class="d-flex gap-2 small">
            <?php if($u): ?>
            <form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="like"><input type="hidden" name="post_id" value="<?= $p['id'] ?>">
              <button class="btn btn-sm btn-outline-danger"><i class="bi bi-heart"></i> <?= (int)$p['likes'] ?></button></form>
            <?php endif; ?>
            <span class="text-muted align-self-center"><i class="bi bi-chat"></i> <?= (int)$p['comments'] ?></span>
          </div>
          <?php $pcs = $commentsByPost[(int)$p['id']] ?? []; if($pcs): ?>
          <div class="mt-2 ps-2 border-start">
            <?php foreach($pcs as $pc): ?>
              <div class="d-flex align-items-start gap-2 mb-1">
                <?= user_avatar($pc['foto_url'] ?? null, $pc['nama'], 22) ?>
                <div class="small flex-grow-1"><strong><?= htmlspecialchars($pc['nama']) ?></strong>
                  <span class="text-muted ms-1" style="font-size:.7rem"><?= date('d M H:i', strtotime($pc['created_at'])) ?></span><br>
                  <?= nl2br(htmlspecialchars($pc['isi'])) ?>
                </div>
                <?php if($u && $u['role']==='admin'): ?>
                  <form method="post" class="d-inline" onsubmit="return confirm('Hapus komentar ini?')">
                    <input type="hidden" name="csrf" value="<?= csrf_token() ?>">
                    <input type="hidden" name="_action" value="comment_delete">
                    <input type="hidden" name="comment_id" value="<?= (int)$pc['id'] ?>">
                    <button class="btn btn-sm btn-link text-danger p-0" title="Hapus komentar (admin)"><i class="bi bi-x-lg"></i></button>
                  </form>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <?php if($u): ?>
          <form method="post" class="d-flex gap-2 mt-2">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="comment"><input type="hidden" name="post_id" value="<?= $p['id'] ?>">
            <input class="form-control form-control-sm" name="isi" placeholder="Tulis komentar..." maxlength="300" required>
            <button class="btn btn-sm btn-primary"><i class="bi bi-send"></i></button>
          </form>
          <?php endif; ?>
        </div>
      <?php endforeach; if(!$feed): ?><p class="text-muted small text-center mb-0">Belum ada postingan.</p><?php endif; ?>
    </div></div>
  </div>

  <div class="col-lg-5">
    <div class="card shadow-sm mb-3"><div class="card-header d-flex justify-content-between align-items-center"><span><i class="bi bi-broadcast text-success me-1"></i> Online (<?= count($onlineMembers) ?>)</span><button class="btn btn-sm btn-link p-0" data-soft-refresh title="Muat data terbaru"><i class="bi bi-arrow-clockwise"></i></button></div>
      <ul class="list-group list-group-flush" data-live="online">
        <?php foreach($onlineMembers as $om): ?>
          <li class="list-group-item d-flex align-items-center justify-content-between">
            <a href="/user.php?id=<?= (int)$om['id'] ?>" class="text-decoration-none"><?= user_name_with_avatar($om['foto_url'] ?? null, $om['nama'], true, 28) ?></a>
            <small class="text-muted"><?= date('H:i', strtotime($om['last_seen'])) ?></small>
          </li>
        <?php endforeach; if(!$onlineMembers): ?><li class="list-group-item text-muted small">Belum ada yang online.</li><?php endif; ?>
      </ul></div>

    <div class="card shadow-sm" id="forum"><div class="card-header d-flex justify-content-between"><span><i class="bi bi-chat-square-text text-primary me-1"></i> Forum Komunitas</span><button class="btn btn-sm btn-link p-0" data-soft-refresh title="Muat data terbaru"><i class="bi bi-arrow-clockwise"></i></button></div>
    <div class="card-body" data-live="forum">
      <?php if($u): ?>
      <form method="post" class="d-flex gap-2 mb-3">
        <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="chat_post">
        <input class="form-control" name="pesan" placeholder="Tulis pesan..." maxlength="500" required>
        <button class="btn btn-primary"><i class="bi bi-send"></i></button>
      </form>
      <?php endif; ?>
      <div style="max-height:520px;overflow-y:auto;">
      <?php foreach($top as $c):
        $rs = $replies[(int)$c['id']] ?? []; ?>
        <div class="chat-bubble">
          <div class="d-flex align-items-center gap-2 mb-1">
            <a href="/user.php?id=<?= (int)$c['user_id'] ?>" class="text-decoration-none"><?= user_avatar($c['foto_url'] ?? null, $c['nama'] ?? '?', 24) ?></a>
            <a href="/user.php?id=<?= (int)$c['user_id'] ?>" class="text-decoration-none fw-semibold"><?= htmlspecialchars($c['nama'] ?? 'Anon') ?></a>
            <small class="chat-meta"><?= date('d M H:i', strtotime($c['created_at'])) ?></small>
          </div>
          <div><?= sanitize_html($c['pesan']) ?></div>
          <div class="d-flex gap-2 mt-1 small">
            <?php if($u): ?>
            <form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="chat_react"><input type="hidden" name="chat_id" value="<?= $c['id'] ?>"><input type="hidden" name="val" value="1">
              <button class="btn btn-sm btn-link text-success p-0 me-2"><i class="bi bi-hand-thumbs-up"></i> <?= (int)$c['likes'] ?></button></form>
            <form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="chat_react"><input type="hidden" name="chat_id" value="<?= $c['id'] ?>"><input type="hidden" name="val" value="-1">
              <button class="btn btn-sm btn-link text-danger p-0 me-2"><i class="bi bi-hand-thumbs-down"></i> <?= (int)$c['dislikes'] ?></button></form>
            <button type="button" class="btn btn-sm btn-link p-0" onclick="document.getElementById('reply<?= $c['id'] ?>').classList.toggle('d-none')"><i class="bi bi-reply"></i> Reply</button>
            <?php if((int)$c['user_id']===(int)$u['id'] || $u['role']==='admin'): ?>
              <button type="button" class="btn btn-sm btn-link p-0 ms-2 text-primary" onclick="document.getElementById('editChat<?= $c['id'] ?>').classList.toggle('d-none')" title="Edit pesan"><i class="bi bi-pencil"></i> Edit</button>
            <?php endif; ?>
            <?php if($u['role']==='admin'): ?>
            <form method="post" class="d-inline" onsubmit="return confirm('Hapus pesan ini?')">
              <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="chat_delete"><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <button class="btn btn-sm btn-link text-danger p-0 ms-2" title="Hapus (admin)"><i class="bi bi-trash"></i></button>
            </form>
            <?php endif; ?>
            <?php else: ?>
              <span class="text-muted"><i class="bi bi-hand-thumbs-up"></i> <?= (int)$c['likes'] ?> · <i class="bi bi-hand-thumbs-down"></i> <?= (int)$c['dislikes'] ?></span>
            <?php endif; ?>
          </div>
          <?php if($u): ?>
          <form method="post" id="reply<?= $c['id'] ?>" class="d-flex gap-2 mt-2 d-none">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="chat_post"><input type="hidden" name="parent_id" value="<?= $c['id'] ?>">
            <input class="form-control form-control-sm" name="pesan" placeholder="Balas pesan..." maxlength="500" required>
            <button class="btn btn-sm btn-primary"><i class="bi bi-send"></i></button>
          </form>
          <?php if((int)$c['user_id']===(int)$u['id'] || $u['role']==='admin'): ?>
          <form method="post" id="editChat<?= $c['id'] ?>" class="d-flex gap-2 mt-2 d-none">
            <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="chat_edit"><input type="hidden" name="id" value="<?= $c['id'] ?>">
            <input class="form-control form-control-sm" name="pesan" value="<?= htmlspecialchars(strip_tags($c['pesan'])) ?>" maxlength="500" required>
            <button class="btn btn-sm btn-primary"><i class="bi bi-save"></i></button>
          </form>
          <?php endif; ?>
          <?php endif; ?>
          <?php foreach($rs as $rep): ?>
            <div class="chat-bubble chat-reply mt-2">
              <div class="d-flex align-items-center gap-2 mb-1">
                <?= user_avatar($rep['foto_url'] ?? null, $rep['nama'] ?? '?', 20) ?>
                <span class="fw-semibold small"><?= htmlspecialchars($rep['nama'] ?? 'Anon') ?></span>
                <small class="chat-meta"><?= date('d M H:i', strtotime($rep['created_at'])) ?></small>
              </div>
              <div class="small"><?= sanitize_html($rep['pesan']) ?></div>
              <?php if($u): ?>
              <div class="d-flex gap-2 mt-1 small">
                <form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="chat_react"><input type="hidden" name="chat_id" value="<?= $rep['id'] ?>"><input type="hidden" name="val" value="1">
                  <button class="btn btn-sm btn-link text-success p-0 me-2"><i class="bi bi-hand-thumbs-up"></i> <?= (int)$rep['likes'] ?></button></form>
                <form method="post" class="d-inline"><input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="chat_react"><input type="hidden" name="chat_id" value="<?= $rep['id'] ?>"><input type="hidden" name="val" value="-1">
                  <button class="btn btn-sm btn-link text-danger p-0"><i class="bi bi-hand-thumbs-down"></i> <?= (int)$rep['dislikes'] ?></button></form>
              </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endforeach; if(!$top): ?><p class="text-muted text-center mb-0 small">Belum ada pesan.</p><?php endif; ?>
      </div>
    </div></div>
  </div>
</div>

<?php if($u): ?>
<div class="modal fade" id="postModal" tabindex="-1"><div class="modal-dialog">
  <form class="modal-content" method="post" enctype="multipart/form-data" id="postNewForm">
    <input type="hidden" name="csrf" value="<?= csrf_token() ?>"><input type="hidden" name="_action" value="post_new">
    <div class="modal-header"><h5 class="modal-title">Posting baru</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
      <label class="form-label small">Tipe</label>
      <select name="jenis" class="form-select mb-2"><option value="post">Post (feed)</option><option value="story">Story (24 jam)</option></select>
      <label class="form-label small">Foto (opsional, maks 5MB)</label>
      <input type="file" name="foto" accept="image/*" class="form-control mb-2" id="postFotoInput">
      <img id="postFotoPreview" class="img-fluid rounded mb-2" style="display:none;max-height:240px">
      <label class="form-label small">Caption</label>
      <textarea name="caption" class="form-control" rows="3" maxlength="500" placeholder="Tulis caption..."></textarea>
    </div>
    <div class="modal-footer">
      <button class="btn btn-primary" id="postSubmitBtn"><i class="bi bi-send"></i> Posting</button>
    </div>
  </form>
</div></div>
<script>
document.addEventListener('DOMContentLoaded', function(){
  var fi=document.getElementById('postFotoInput');
  var pv=document.getElementById('postFotoPreview');
  if(fi){ fi.addEventListener('change', function(){
    var f=this.files && this.files[0]; if(!f){ pv.style.display='none'; return; }
    pv.src=URL.createObjectURL(f); pv.style.display='block';
  });}
  var fm=document.getElementById('postNewForm');
  if(fm){ fm.addEventListener('submit', function(){
    var btn=document.getElementById('postSubmitBtn');
    if(btn){ btn.disabled=true; btn.innerHTML='<span class="spinner-border spinner-border-sm me-1"></span> Mengunggah...'; }
    var pre=document.getElementById('appPreloader');
    if(pre){ pre.classList.remove('hidden'); pre.querySelector('.lbl').textContent='Mengunggah foto...'; }
    else {
      var p=document.createElement('div'); p.id='appPreloader';
      p.innerHTML='<div class="spinner"></div><div class="lbl">Mengunggah foto...</div>';
      document.body.appendChild(p);
    }
  });}
});
</script>
<?php endif; ?>

<!-- QR Modal -->
<div class="modal fade" id="qrModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered">
  <div class="modal-content">
    <div class="modal-header"><h5 class="modal-title"><i class="bi bi-qr-code"></i> <span id="qrTitle">QR Sesi</span></h5>
      <button class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body text-center">
      <div class="small text-muted mb-2" id="qrMeta"></div>
      <img id="qrImg" src="" alt="QR" class="img-fluid" style="max-width:340px;border:1px solid #eee;border-radius:8px;">
      <div class="small text-muted mt-2"><code id="qrToken"></code></div>
    </div>
    <div class="modal-footer">
      <a id="qrDownload" download="qr-checkin.png" class="btn btn-primary"><i class="bi bi-download"></i> Unduh QR Code</a>
      <a id="qrCheckin" href="/checkin.php" class="btn btn-outline-secondary"><i class="bi bi-camera"></i> Buka Check-in</a>
    </div>
  </div>
</div></div>

<!-- Story Modal -->
<div class="modal fade" id="storyModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered">
  <div class="modal-content">
    <div class="modal-header"><h5 class="modal-title"><i class="bi bi-collection-play"></i> Story <small id="storyName" class="text-muted ms-2"></small></h5>
      <button class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body text-center">
      <img id="storyImg" src="" alt="" class="img-fluid mb-2" style="max-height:60vh;border-radius:8px;display:none;">
      <div id="storyCaption" class="text-start"></div>
      <div class="small text-muted mt-2" id="storyTime"></div>
    </div>
  </div>
</div></div>

<script>
let _qrM=null,_stM=null;
function showQR(token, jenis, tanggal, tempat){
  if(!_qrM) _qrM=new bootstrap.Modal(document.getElementById('qrModal'));
  const src='https://api.qrserver.com/v1/create-qr-code/?size=400x400&data='+encodeURIComponent(token);
  document.getElementById('qrTitle').textContent=jenis+' · '+tanggal;
  document.getElementById('qrMeta').textContent=tempat;
  document.getElementById('qrImg').src=src;
  document.getElementById('qrToken').textContent=token;
  // Unduh: ambil sebagai blob agar nama file rapi
  const a=document.getElementById('qrDownload');
  a.href=src; a.download='qr-'+(jenis||'sesi')+'-'+(tanggal||'')+'.png';
  a.onclick=async function(ev){
    ev.preventDefault();
    try{
      const r=await fetch(src); const b=await r.blob();
      const url=URL.createObjectURL(b);
      const dl=document.createElement('a'); dl.href=url; dl.download=a.download; dl.click();
      setTimeout(()=>URL.revokeObjectURL(url),1500);
    }catch(e){ window.open(src,'_blank'); }
  };
  _qrM.show();
}
function showStory(d){
  if(!_stM) _stM=new bootstrap.Modal(document.getElementById('storyModal'));
  document.getElementById('storyName').textContent=d.nama||'';
  const img=document.getElementById('storyImg');
  if(d.foto){ img.src=d.foto; img.style.display='block'; } else { img.style.display='none'; }
  document.getElementById('storyCaption').textContent=d.caption||'';
  document.getElementById('storyTime').textContent=d.created_at||'';
  _stM.show();
}
</script>

<?php include __DIR__.'/includes/footer.php'; ?>
