<?php
// Riwayat + Leaderboard + Riwayat Aktivitas (dengan bukti popup)
require __DIR__.'/config/db.php';
require __DIR__.'/includes/auth.php';
require __DIR__.'/includes/security.php';
require __DIR__.'/includes/helpers.php';
send_security_headers(); enforce_session_timeout();
$pageTitle = 'Riwayat & Leaderboard';
$u = current_user();

$period = $_GET['period'] ?? 'monthly';
$cat = $_GET['cat'] ?? 'konsisten';

$periodSql = "j.tanggal >= CURRENT_DATE - INTERVAL '30 days'";
if ($period === 'weekly') $periodSql = "j.tanggal >= CURRENT_DATE - INTERVAL '7 days'";
if ($period === 'all')    $periodSql = "TRUE";

$uPeriodSql = str_replace('j.tanggal','uh.tanggal',$periodSql);

$lb = [];
if ($cat === 'konsisten') {
    $lb = db_all("SELECT u.id,u.nama,u.foto_url, COUNT(*) AS skor
                  FROM absensi a JOIN jadwal j ON j.id=a.jadwal_id JOIN users u ON u.id=a.user_id
                  WHERE a.hadir=1 AND $periodSql
                  GROUP BY u.id,u.nama,u.foto_url ORDER BY skor DESC LIMIT 20");
} elseif ($cat === 'jarak') {
    $lb = db_all("SELECT u.id,u.nama,u.foto_url, COALESCE(SUM(uh.jarak_km),0) AS skor
                  FROM upload_harian uh JOIN users u ON u.id=uh.user_id
                  WHERE $uPeriodSql
                  GROUP BY u.id,u.nama,u.foto_url ORDER BY skor DESC LIMIT 20");
} elseif ($cat === 'pace') {
    $lb = db_all("SELECT u.id,u.nama,u.foto_url, MIN(uh.pace_detik) AS skor
                  FROM upload_harian uh JOIN users u ON u.id=uh.user_id
                  WHERE $uPeriodSql AND uh.pace_detik IS NOT NULL
                  GROUP BY u.id,u.nama,u.foto_url ORDER BY skor ASC LIMIT 20");
} elseif ($cat === 'kalori') {
    $lb = db_all("SELECT u.id,u.nama,u.foto_url, COALESCE(SUM(uh.kalori),0) AS skor
                  FROM upload_harian uh JOIN users u ON u.id=uh.user_id
                  WHERE $uPeriodSql
                  GROUP BY u.id,u.nama,u.foto_url ORDER BY skor DESC LIMIT 20");
} else {
    $lb = db_all("SELECT u.id,u.nama,u.foto_url,
                    (COUNT(DISTINCT j.jenis)*10 + COUNT(*)) AS skor
                  FROM absensi a JOIN jadwal j ON j.id=a.jadwal_id JOIN users u ON u.id=a.user_id
                  WHERE a.hadir=1 AND $periodSql
                  GROUP BY u.id,u.nama,u.foto_url ORDER BY skor DESC LIMIT 20");
}

$riwayat = db_all("SELECT j.*, u.nama AS koord, u.foto_url AS koord_foto,
                          (SELECT COUNT(*) FROM absensi a WHERE a.jadwal_id=j.id AND a.hadir=1) AS hadir,
                          (SELECT COUNT(*) FROM absensi a WHERE a.jadwal_id=j.id) AS total
                   FROM jadwal j LEFT JOIN users u ON u.id=j.koordinator_id
                   ORDER BY j.tanggal DESC LIMIT 50");

// Riwayat aktivitas saya (untuk bukti popup)
$myActs = $u ? db_all("SELECT id,tanggal,jenis,durasi_menit,jarak_km,kalori,file_path,deskripsi
                       FROM upload_harian WHERE user_id=$1 ORDER BY tanggal DESC LIMIT 30", [(int)$u['id']]) : [];
include __DIR__.'/includes/header.php';
?>
<h2 class="mb-3"><i class="bi bi-clock-history text-primary"></i> Riwayat & Leaderboard</h2>

<div class="card shadow-sm mb-3"><div class="card-body">
  <form class="row g-2 align-items-end">
    <div class="col-md-3"><label class="small fw-semibold">Kategori</label>
      <select name="cat" class="form-select" onchange="this.form.submit()">
        <?php foreach(['konsisten'=>'Paling Konsisten','jarak'=>'Jarak Terbanyak','pace'=>'Pace Terbaik','kalori'=>'Kalori Terbanyak','all'=>'All Rounder'] as $k=>$v): ?>
          <option value="<?= $k ?>" <?= $cat===$k?'selected':'' ?>><?= $v ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="col-md-3"><label class="small fw-semibold">Periode</label>
      <select name="period" class="form-select" onchange="this.form.submit()">
        <option value="weekly"  <?= $period==='weekly'?'selected':'' ?>>Mingguan</option>
        <option value="monthly" <?= $period==='monthly'?'selected':'' ?>>Bulanan</option>
        <option value="all"     <?= $period==='all'?'selected':'' ?>>All-time</option>
      </select></div>
  </form>
</div></div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="card shadow-sm"><div class="card-header"><i class="bi bi-trophy-fill text-warning"></i> Leaderboard — <?= htmlspecialchars($cat) ?></div>
    <ol class="list-group list-group-flush list-group-numbered">
      <?php foreach($lb as $i=>$row): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
          <a href="/user.php?id=<?= (int)$row['id'] ?>" class="text-decoration-none">
            <?= user_name_with_avatar($row['foto_url'] ?? null, $row['nama'], false, 28) ?>
          </a>
          <span class="badge bg-primary rounded-pill">
            <?php
              if ($cat==='jarak') echo number_format((float)$row['skor'],2).' km';
              elseif ($cat==='pace') { $s=(int)$row['skor']; echo sprintf('%d:%02d /km', intdiv($s,60), $s%60); }
              elseif ($cat==='kalori') echo number_format((int)$row['skor']).' kkal';
              else echo (int)$row['skor'];
            ?>
          </span>
        </li>
      <?php endforeach; if(!$lb): ?><li class="list-group-item text-muted text-center small">Belum ada data.</li><?php endif; ?>
    </ol></div>
  </div>

  <div class="col-lg-7">
    <div class="card shadow-sm mb-3"><div class="card-header"><i class="bi bi-calendar3 text-primary"></i> Riwayat Sesi</div>
    <div class="table-responsive"><table class="table table-hover table-stack mb-0">
      <thead><tr><th>Tanggal</th><th>Jenis</th><th>Tempat</th><th>Kehadiran</th></tr></thead>
      <tbody>
      <?php foreach($riwayat as $r): ?>
        <tr>
          <td data-label="Tanggal"><?= htmlspecialchars($r['tanggal']) ?> <span class="pill"><?= hari_id($r['tanggal']) ?></span></td>
          <td data-label="Jenis"><?= htmlspecialchars($r['jenis']) ?></td>
          <td data-label="Tempat"><?= htmlspecialchars($r['tempat']) ?></td>
          <td data-label="Hadir"><?= (int)$r['hadir'] ?>/<?= (int)$r['total'] ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div>
    </div>

    <?php if($u): ?>
    <div class="card shadow-sm"><div class="card-header"><i class="bi bi-activity text-primary"></i> Riwayat Aktifitas Saya</div>
    <div class="table-responsive"><table class="table table-hover mb-0">
      <thead><tr><th>Tanggal</th><th>Jenis</th><th>Durasi</th><th>Jarak</th><th>Kalori</th><th>Bukti</th></tr></thead>
      <tbody>
        <?php foreach($myActs as $a): ?>
        <tr>
          <td><?= htmlspecialchars($a['tanggal']) ?></td>
          <td><span class="pill"><?= htmlspecialchars($a['jenis']) ?></span></td>
          <td><?= (int)$a['durasi_menit'] ?> mnt</td>
          <td><?= htmlspecialchars($a['jarak_km']) ?> km</td>
          <td><?= (int)$a['kalori'] ?></td>
          <td>
            <?php if($a['file_path']): ?>
              <a href="#" onclick="showBukti(event,'<?= htmlspecialchars($a['file_path'],ENT_QUOTES) ?>','<?= htmlspecialchars($a['tanggal']) ?>')">
                <img src="<?= htmlspecialchars($a['file_path']) ?>" alt="bukti" style="height:42px;width:42px;object-fit:cover;border-radius:6px;cursor:zoom-in;border:1px solid #ddd;">
              </a>
            <?php else: ?>-<?php endif; ?>
          </td>
        </tr>
        <?php endforeach; if(!$myActs): ?><tr><td colspan="6" class="text-center text-muted small py-3">Belum ada aktivitas.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Bukti modal -->
<div class="modal fade" id="buktiModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title"><i class="bi bi-image"></i> Bukti Aktivitas <small id="bDate" class="text-muted ms-2"></small></h5>
        <button class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body text-center"><img id="bImg" src="" style="max-width:100%;border-radius:8px;"></div>
      <div class="modal-footer"><a id="bOpen" href="#" target="_blank" class="btn btn-sm btn-outline-primary"><i class="bi bi-box-arrow-up-right"></i> Buka di tab baru</a></div>
    </div>
  </div>
</div>
<script>
let _bModal=null;
function showBukti(ev, src, date){
  if(ev) ev.preventDefault();
  if(!_bModal) _bModal = new bootstrap.Modal(document.getElementById('buktiModal'));
  document.getElementById('bImg').src = src;
  document.getElementById('bOpen').href = src;
  document.getElementById('bDate').textContent = date || '';
  _bModal.show();
}
</script>
<?php include __DIR__.'/includes/footer.php'; ?>
